package de.ait_tr.g_36.domain.entity;

public class Cart {
}
